// +build !go1.8

package simple

import "go/types"

var structsIdentical = types.Identical
