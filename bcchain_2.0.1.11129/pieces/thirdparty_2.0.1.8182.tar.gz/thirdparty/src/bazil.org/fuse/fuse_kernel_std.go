package fuse
