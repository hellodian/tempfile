package genesis

import (
	"blockchain/smcsdk/sdk/std"
	"blockchain/smcsdk/sdk/types"
)

// RequestInitChain genesis info
type RequestInitChain struct {
	Validators []Validator  `json:"validators"`
	ChainID    string       `json:"chain_id"`
	AppState   InitAppState `json:"app_state"`
}

// Validator validator info
type Validator struct {
	PubKey     []byte `json:"pub_key,omitempty"`
	Power      int64  `json:"power,omitempty"`
	RewardAddr string `json:"reward_addr,omitempty"`
	Name       string `json:"name,omitempty"`
	NodeAddr   string `json:"node_addr,omitempty"`
}

// InitAppState initChain app state info
type InitAppState struct {
	Organization   string     `json:"organization"`
	Token          std.Token  `json:"token"`
	RewardStrategy []Reward   `json:"rewardStrategy"`
	Contracts      []Contract `json:"contracts"`
}

// Reward reward info
type Reward struct {
	Name          string `json:"name"`          // 被奖励者名称
	RewardPercent string `json:"rewardPercent"` // 奖励比例
	Address       string `json:"address"`       // 被奖励者地址
}

// Contract contract info
type Contract struct {
	Name       string         `json:"name,omitempty"`
	Version    string         `json:"version,omitempty"`
	CodeByte   types.HexBytes `json:"codeByte,omitempty"`
	CodeHash   string         `json:"codeHash,omitempty"`
	CodeDevSig Signature      `json:"codeDevSig,omitempty"`
	CodeOrgSig Signature      `json:"codeOrgSig,omitempty"`
}

// Signature sig for contract code
type Signature struct {
	PubKey    string `json:"pubkey"`
	Signature string `json:"signature"`
}

// RewardStrategy stored reward list and effectHeight
type RewardStrategy struct {
	Strategy     []Reward `json:"rewardStrategy,omitempty"` //奖励策略
	EffectHeight uint64   `json:"effectHeight,omitempty"`   //生效高度
}

// ResponseInitChain return info for genesis
type ResponseInitChain struct {
	Code        uint32 `json:"code,omitempty"`
	Log         string `json:"log,omitempty"`
	GenAppState []byte `json:"gen_app_state,omitempty"`
}

// AppState world app state
type AppState struct {
	BlockHeight  int64          `json:"block_height,omitempty"`  //最后一个确认的区块高度
	AppHash      types.HexBytes `json:"app_hash,omitempty"`      //最后一个确认区块的AppHash
	ChainVersion int64          `json:"chain_version,omitempty"` //当前链版本
}

const (
	// MaxNameLen name max length
	MaxNameLen = 40
	// MaxSymbolLen token symbol can be up to 20 characters
	MaxSymbolLen = 20
)
