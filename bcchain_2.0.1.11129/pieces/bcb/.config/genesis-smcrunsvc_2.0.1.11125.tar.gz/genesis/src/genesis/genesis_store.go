package genesis

import (
	"blockchain/smcsdk/sdk/std"
	"blockchain/smcsdk/sdk/types"
	"strings"
)

// _chainID get chainID
func (g *Genesis) _chainID() (chainID string) {
	return *g.sdk.Helper().StateHelper().GetEx("/genesis/chainid", &chainID).(*string)
}

// _setChainID set chainID
func (g *Genesis) _setChainID(chainID string) {
	key := "/genesis/chainid"
	g.sdk.Helper().StateHelper().Set(key, &chainID)
	g.appStateKeys = append(g.appStateKeys, key)
}

// _chkChainID check chainID exist
func (g *Genesis) _chkChainID() (ok bool) {
	return g.sdk.Helper().StateHelper().Check("/genesis/chainid")
}

// _setStrategys set reward strategy
func (g *Genesis) _setStrategys(rewardStrategys []RewardStrategy) {
	key := "/rewardstrategys"
	g.sdk.Helper().StateHelper().Set(key, &rewardStrategys)
	g.appStateKeys = append(g.appStateKeys, key)
}

// _Strategys get reward strategy
func (g *Genesis) _strategys() (rewardStrategys []RewardStrategy) {
	return *g.sdk.Helper().StateHelper().GetEx("/rewardstrategys", &rewardStrategys).(*[]RewardStrategy)
}

// _chkStrategys check reward strategy
func (g *Genesis) _chkStrategys() bool {
	return g.sdk.Helper().StateHelper().Check("/rewardstrategys")
}

// validator
func (g *Genesis) _validator(nodeAddr string) Validator {
	return *g.sdk.Helper().StateHelper().GetEx("/validator/"+nodeAddr, &Validator{}).(*Validator)
}

func (g *Genesis) _setValidator(validator Validator) {
	key := "/validator/" + validator.NodeAddr
	g.sdk.Helper().StateHelper().Set(key, &validator)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkValidator(validatorAddr string) bool {
	return g.sdk.Helper().StateHelper().Check("/validator/" + validatorAddr)
}

// all validators pubKeys
func (g *Genesis) _validatorPubKeys() [][]byte {
	return *g.sdk.Helper().StateHelper().GetEx("/validator/all/0", &[][]byte{}).(*[][]byte)
}

func (g *Genesis) _setValidatorPubKeys(pubKeys [][]byte) {
	g.sdk.Helper().StateHelper().Set("/validator/all/0", &pubKeys)
}

func (g *Genesis) _chkValidatorPubKeys() bool {
	return g.sdk.Helper().StateHelper().Check("/validator/all/0")
}

// _setGenesisToken set genesis token
func (g *Genesis) _setGenesisToken(token std.Token) {
	key := "/genesis/token"
	g.sdk.Helper().StateHelper().Set(key, &token)
	g.appStateKeys = append(g.appStateKeys, key)
}

// _genesisToken get genesis token
func (g *Genesis) _genesisToken() std.Token {
	return *g.sdk.Helper().StateHelper().GetEx("/genesis/token", new(std.Token)).(*std.Token)
}

// _chkGenesisToken
func (g *Genesis) _chkGenesisToken() bool {
	return g.sdk.Helper().StateHelper().Check("/genesis/token")
}

// _setAccount set account info
func (g *Genesis) _setAccountInfo(accountAddr, tokenAddr string, accountInfo std.AccountInfo) {
	key := "/account/ex/" + accountAddr + "/token/" + tokenAddr
	g.sdk.Helper().StateHelper().Set(key, &accountInfo)
	g.appStateKeys = append(g.appStateKeys, key)
	g.accountChildKeys = append(g.accountChildKeys, key)
}

// _account get account
func (g *Genesis) _accountIfo(accountAddr, tokenAddr string) std.AccountInfo {
	return *g.sdk.Helper().StateHelper().GetEx("/account/ex/"+accountAddr+"/token/"+tokenAddr, new(std.AccountInfo)).(*std.AccountInfo)
}

// _chkAccount check account
func (g *Genesis) _chkAccountInfo(accountAddr, tokenAddr string) bool {
	return g.sdk.Helper().StateHelper().Check("/account/ex/" + accountAddr + "/token/" + tokenAddr)
}

// contract
func (g *Genesis) _contract(addr string) std.Contract {
	return *g.sdk.Helper().StateHelper().GetEx("/contract/"+addr, new(std.Contract)).(*std.Contract)
}

func (g *Genesis) _setContract(contract std.Contract) {
	key := "/contract/" + contract.Address
	g.sdk.Helper().StateHelper().Set(key, &contract)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkContract(addr string) bool {
	return g.sdk.Helper().StateHelper().Check("/contract/" + addr)
}

// token
func (g *Genesis) _token(addr types.Address) std.Token {
	return *g.sdk.Helper().StateHelper().GetEx("/token/"+addr, new(std.Token)).(*std.Token)
}

func (g *Genesis) _setToken(token std.Token) {
	key := "/token/" + token.Address
	g.sdk.Helper().StateHelper().Set(key, &token)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkToken(addr types.Address) bool {
	return g.sdk.Helper().StateHelper().Check("/token" + addr)
}

// token name
func (g *Genesis) _tokenName(name string) (tokenAddr string) {
	return *g.sdk.Helper().StateHelper().GetEx("/token/name/"+strings.ToLower(name), &tokenAddr).(*string)
}

func (g *Genesis) _setTokenName(name string, addr types.Address) {
	key := "/token/name/" + strings.ToLower(name)
	g.sdk.Helper().StateHelper().Set(key, &addr)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkTokenName(name string) bool {
	return g.sdk.Helper().StateHelper().Check("/token/name/" + strings.ToLower(name))
}

// token symbol
func (g *Genesis) _tokenSymbol(symbol string) (tokenAddr string) {
	return *g.sdk.Helper().StateHelper().GetEx("/token/symbol/"+strings.ToLower(symbol), &tokenAddr).(*string)
}

func (g *Genesis) _setTokenSymbol(symbol string, addr types.Address) {
	key := "/token/symbol/" + strings.ToLower(symbol)
	g.sdk.Helper().StateHelper().Set(key, &addr)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkTokenSymbol(symbol string) bool {
	return g.sdk.Helper().StateHelper().Check("/token/symbol/" + strings.ToLower(symbol))
}

// token base gas price
func (g *Genesis) _tokenBaseGasPrice(symbol string, addr types.Address) int64 {
	return *g.sdk.Helper().StateHelper().GetEx("/token/basegasprice", new(int64)).(*int64)
}

func (g *Genesis) _setTokenBaseGasPrice(value int64) {
	key := "/token/basegasprice"
	g.sdk.Helper().StateHelper().Set(key, &value)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkTokenBaseGasPrice() bool {
	return g.sdk.Helper().StateHelper().Check("/token/basegasprice")
}

// organization
func (g *Genesis) _organization(orgID string) std.Organization {
	return *g.sdk.Helper().StateHelper().GetEx("/organization/"+orgID, new(std.Organization)).(*std.Organization)
}

func (g *Genesis) _setOrganization(org std.Organization) {
	key := "/organization/" + org.OrgID
	g.sdk.Helper().StateHelper().Set(key, &org)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkOrganization(orgID string) bool {
	return g.sdk.Helper().StateHelper().Check("/organization/" + orgID)
}

// orgAuthDeployContract
func (g *Genesis) _orgAuthDeployContract(orgID string) types.Address {
	return *g.sdk.Helper().StateHelper().GetEx("/organization/"+orgID+"/auth", new(types.Address)).(*types.Address)
}

func (g *Genesis) _setOrgAuthDeployContract(orgID string, addr types.Address) {
	g.sdk.Helper().StateHelper().Set("/organization/"+orgID+"/auth", &addr)
}

func (g *Genesis) _chkOrgAuthDeployContract(orgID string) bool {
	return g.sdk.Helper().StateHelper().Check("/organization/" + orgID + "/auth")
}

// contract metadata
func (g *Genesis) _contractMeta(contractAddr string) std.ContractMeta {
	return *g.sdk.Helper().StateHelper().GetEx("/contract/code/"+contractAddr, new(std.ContractMeta)).(*std.ContractMeta)
}

func (g *Genesis) _setContractMeta(meta std.ContractMeta) {
	key := "/contract/code/" + meta.ContractAddr
	g.sdk.Helper().StateHelper().Set("/contract/code/"+meta.ContractAddr, &meta)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkContractMeta(contractAddr string) bool {
	return g.sdk.Helper().StateHelper().Check("/contract/code/" + contractAddr)
}

// contract version & effect height list
func (g *Genesis) _contractVersionList(orgID, name string) std.ContractVersionList {
	return *g.sdk.Helper().StateHelper().GetEx("/contract/"+orgID+"/"+name, new(std.ContractVersionList)).(*std.ContractVersionList)
}

func (g *Genesis) _setContractVersionInfo(info std.ContractVersionList, orgID string) {
	key := "/contract/" + orgID + "/" + info.Name
	g.sdk.Helper().StateHelper().Set("/contract/"+orgID+"/"+info.Name, &info)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkContractVersionList(orgID, name string) bool {
	return g.sdk.Helper().StateHelper().Check("/contract/" + orgID + "/" + name)
}

// world app state
func (g *Genesis) _worldAppstate() AppState {
	return *g.sdk.Helper().StateHelper().GetEx("/world/appstate", new(AppState)).(*AppState)
}

func (g *Genesis) _setWorldAppState(state AppState) {
	key := "/world/appstate"
	g.sdk.Helper().StateHelper().Set(key, &state)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkWorldAppState() bool {
	return g.sdk.Helper().StateHelper().Check("/world/appstate")
}

// Account child keys
func (g *Genesis) _accountChildKeys(addr types.Address) []string {
	return *g.sdk.Helper().StateHelper().GetEx("/account/ex/"+addr, new([]string)).(*[]string)
}

func (g *Genesis) _setAccountChildKeys(addr types.Address, value []string) {
	key := "/account/ex/" + addr
	g.sdk.Helper().StateHelper().Set(key, &value)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkAccountChildKeys(addr types.Address) bool {
	return g.sdk.Helper().StateHelper().Check("/account/ex/" + addr)
}

// genesis contracts
func (g *Genesis) _genesisContracts() []string {
	return *g.sdk.Helper().StateHelper().GetEx("/genesis/contracts", new([]string)).(*[]string)
}

func (g *Genesis) _setGenesisContracts(contractAddrs []string) {
	key := "/genesis/contracts"
	g.sdk.Helper().StateHelper().Set("/genesis/contracts", &contractAddrs)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkGenesisContracts() bool {
	return g.sdk.Helper().StateHelper().Check("/genesis/contracts")
}

// account/ex/账户地址/contracts
func (g *Genesis) _accountContracts(accountAddr types.Address) []string {
	return *g.sdk.Helper().StateHelper().GetEx("/account/ex/"+accountAddr+"/contracts", new([]string)).(*[]string)
}

func (g *Genesis) _setAccountContracts(accountAddr types.Address, contractAddrs []types.Address) {
	key := "/account/ex/" + accountAddr + "/contracts"
	g.sdk.Helper().StateHelper().Set(key, &contractAddrs)
	g.accountChildKeys = append(g.accountChildKeys, key)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkAccountContracts(accountAddr types.Address) bool {
	return g.sdk.Helper().StateHelper().Check("/account/ex/" + accountAddr + "/contracts")
}

// genesis/sc/合约地址
func (g *Genesis) _genesisContract(contractAddr types.Address) std.Contract {
	return *g.sdk.Helper().StateHelper().GetEx("/genesis/sc/"+contractAddr, new(std.Contract)).(*std.Contract)
}

func (g *Genesis) _setGenesisContract(contract std.Contract) {
	key := "/genesis/sc/" + contract.Address
	g.sdk.Helper().StateHelper().Set(key, &contract)
	g.appStateKeys = append(g.appStateKeys, key)
}

func (g *Genesis) _chkGenesisContract(contractAddr types.Address) bool {
	return g.sdk.Helper().StateHelper().Check("/genesis/sc/" + contractAddr)
}

// all contract address
func (g *Genesis) _allContractAddr() []types.Address {
	return *g.sdk.Helper().StateHelper().GetEx(std.KeyOfAllContracts(), new([]types.Address)).(*[]types.Address)
}

func (g *Genesis) _setAllContractAddr(value []types.Address) {
	g.sdk.Helper().StateHelper().Set(std.KeyOfAllContracts(), &value)
}

func (g *Genesis) _chkAllContractAddr() bool {
	return g.sdk.Helper().StateHelper().Check(std.KeyOfAllContracts())
}

// all token address
func (g *Genesis) _allTokenAddress() []types.Address {
	return *g.sdk.Helper().StateHelper().GetEx(std.KeyOfAllToken(), new([]types.Address)).(*[]types.Address)
}

func (g *Genesis) _setAllToken(value []types.Address) {
	g.sdk.Helper().StateHelper().Set(std.KeyOfAllToken(), &value)
}

func (g *Genesis) _chkAllToken() bool {
	return g.sdk.Helper().StateHelper().Check(std.KeyOfAllToken())
}

func (g *Genesis) _setChainVersion(version int) {
	key := "/genesis/chainversion"
	g.appStateKeys = append(g.appStateKeys, key)
	g.sdk.Helper().StateHelper().Set(key, &version)
}
