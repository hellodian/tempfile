package log

func dup2(fd1, fd2 int) {}
