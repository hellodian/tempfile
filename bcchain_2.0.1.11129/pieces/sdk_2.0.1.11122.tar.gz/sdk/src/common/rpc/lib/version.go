package rpc

const Maj = "0"
const Min = "7"
const Fix = "0"

const Version = Maj + "." + Min + "." + Fix
