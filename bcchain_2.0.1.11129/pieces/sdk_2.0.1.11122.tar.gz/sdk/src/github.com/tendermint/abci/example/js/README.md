This example has been moved here: https://github.com/tendermint/js-abci/tree/master/example
