package version

// NOTE: we should probably be versioning the ABCI and the abci-cli separately

const Maj = "0"
const Min = "10"
const Fix = "3"

const Version = "0.10.3"
