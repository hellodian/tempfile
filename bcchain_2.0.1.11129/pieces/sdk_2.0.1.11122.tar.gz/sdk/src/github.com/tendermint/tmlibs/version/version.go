package version

const Version = "0.8.2"
