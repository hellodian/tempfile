TODO: syndtr/goleveldb should be replaced with actual LevelDB instance
