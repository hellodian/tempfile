Tendermint Go-DB Copyright (C) 2015 All in Bits, Inc

Released under the Apache2.0 license
