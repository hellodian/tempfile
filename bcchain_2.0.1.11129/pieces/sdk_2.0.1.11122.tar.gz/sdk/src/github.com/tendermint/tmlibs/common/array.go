package common

func Arr(items ...interface{}) []interface{} {
	return items
}
