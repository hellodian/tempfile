package main

import (
	_ "github.com/tendermint/go-wire/gen"
)
