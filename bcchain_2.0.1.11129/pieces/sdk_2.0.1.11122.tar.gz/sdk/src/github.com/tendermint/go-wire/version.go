package wire

const Version = "0.7.3"
