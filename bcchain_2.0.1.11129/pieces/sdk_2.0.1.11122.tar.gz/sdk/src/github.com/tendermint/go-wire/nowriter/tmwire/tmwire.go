package tmwire

func empty() {
	// test suite for tendermint encoding and decoding package tmwire
}
