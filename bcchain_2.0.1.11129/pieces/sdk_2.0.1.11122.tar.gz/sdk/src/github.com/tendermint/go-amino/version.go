package amino

// Version
const Version = "0.9.7"
