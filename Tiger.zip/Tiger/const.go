package tiger

//W=0
//K=4
//Q=3
//J=2
//S=1
const (
	PERMILLE = 1000
	ARRAYSIZE=5

)


