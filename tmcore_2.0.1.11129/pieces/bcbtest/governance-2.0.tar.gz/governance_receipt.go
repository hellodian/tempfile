package governance

import (
	"blockchain/smcsdk/sdk/types"
)

func (g *Governance) emitNewValidator(
	name string,
	nodePubKey types.PubKey,
	nodeAddr types.Address,
	rewardAddr types.Address,
	power int64) {

	type newValidator struct {
		Name       string        `json:"name,omitempty"`       //节点名称
		NodePubKey types.PubKey  `json:"nodePubKey,omitempty"` //节点公钥
		NodeAddr   types.Address `json:"nodeAddr,omitempty"`   //节点地址
		RewardAddr types.Address `json:"rewardAddr,omitempty"` //节点接收奖励的地址
		Power      int64         `json:"power,omitempty"`      //节点记账权重
	}

	g.sdk.Helper().ReceiptHelper().Emit(
		newValidator{
			Name:       name,
			NodePubKey: nodePubKey,
			NodeAddr:   nodeAddr,
			RewardAddr: rewardAddr,
			Power:      power,
		},
	)
}

func (g *Governance) emitSetPower(
	name string,
	nodePubKey types.PubKey,
	nodeAddr types.Address,
	rewardAddr types.Address,
	power int64) {

	type setPower struct {
		Name       string        `json:"name,omitempty"`       //节点名称
		NodePubKey types.PubKey  `json:"nodePubKey,omitempty"` //节点公钥
		NodeAddr   types.Address `json:"nodeAddr,omitempty"`   //节点地址
		RewardAddr types.Address `json:"rewardAddr,omitempty"` //节点接收奖励的地址
		Power      int64         `json:"power,omitempty"`      //节点记账权重
	}

	g.sdk.Helper().ReceiptHelper().Emit(
		setPower{
			Name:       name,
			NodePubKey: nodePubKey,
			NodeAddr:   nodeAddr,
			RewardAddr: rewardAddr,
			Power:      power,
		},
	)
}

func (g *Governance) emitSetRewardAddr(
	name string,
	nodePubKey types.PubKey,
	nodeAddr types.Address,
	rewardAddr types.Address,
	power int64) {

	type setRewardAddr struct {
		Name       string        `json:"name,omitempty"`       //节点名称
		NodePubKey types.PubKey  `json:"nodePubKey,omitempty"` //节点公钥
		NodeAddr   types.Address `json:"nodeAddr,omitempty"`   //节点地址
		RewardAddr types.Address `json:"rewardAddr,omitempty"` //节点接收奖励的地址
		Power      int64         `json:"power,omitempty"`      //节点记账权重
	}

	g.sdk.Helper().ReceiptHelper().Emit(
		setRewardAddr{
			Name:       name,
			NodePubKey: nodePubKey,
			NodeAddr:   nodeAddr,
			RewardAddr: rewardAddr,
			Power:      power,
		},
	)
}

func (g *Governance) emitSetRewardStrategy(rewards []Reward, effectHeight int64) {

	type setRewardStrategy struct {
		Strategy     []Reward `json:"rewardStrategy,omitempty"` //奖励策略
		EffectHeight int64    `json:"effectHeight,omitempty"`   //生效高度
	}

	g.sdk.Helper().ReceiptHelper().Emit(
		setRewardStrategy{
			Strategy:     rewards,
			EffectHeight: effectHeight,
		},
	)
}
