package governance

// all validators pubKeys
func (g *Governance) _validatorPubKeys() [][]byte {
	return *g.sdk.Helper().StateHelper().GetEx("/validator/all/0", &[][]byte{}).(*[][]byte)
}

func (g *Governance) _setValidatorPubKeys(pubKeys [][]byte) {
	g.sdk.Helper().StateHelper().Set("/validator/all/0", &pubKeys)
}

func (g *Governance) _chkValidatorPubKeys() bool {
	return g.sdk.Helper().StateHelper().Check("/validator/all/0")
}

// validator
func (g *Governance) _validator(nodeAddr string) InfoOfValidator {
	return *g.sdk.Helper().StateHelper().GetEx("/validator/"+nodeAddr, &InfoOfValidator{}).(*InfoOfValidator)
}

func (g *Governance) _setValidator(validator InfoOfValidator) {
	g.sdk.Helper().StateHelper().Set("/validator/"+validator.NodeAddr, &validator)
}

func (g *Governance) _chkValidator(validatorAddr string) bool {
	return g.sdk.Helper().StateHelper().Check("/validator/" + validatorAddr)
}

// 奖励策略
func (g *Governance) _rewardStrategies() (rewardStrategys []RewardStrategy) {
	return *g.sdk.Helper().StateHelper().GetEx("/rewardstrategys", &rewardStrategys).(*[]RewardStrategy)
}

func (g *Governance) _setRewardStrategies(rewardStrategys []RewardStrategy) {
	g.sdk.Helper().StateHelper().Set("/rewardstrategys", &rewardStrategys)
}

func (g *Governance) _chkRewardStrategies() bool {
	return g.sdk.Helper().StateHelper().Check("/rewardstrategys")
}
