package governance

import (
	"strconv"
	"strings"

	"blockchain/smcsdk/sdk"
	"blockchain/smcsdk/sdk/bn"
	"blockchain/smcsdk/sdk/jsoniter"
	"blockchain/smcsdk/sdk/types"
)

//Governance manage validators
//@:contract:governance
//@:version:2.0
//@:organization:orgJgaGConUyK81zibntUBjQ33PKctpk1K1G
//@:author:5e8339cb1a5cce65602fd4f57e115905348f7e83bcbe38dd77694dbe1f8903c9
type Governance struct {
	sdk sdk.ISmartContract
}

//InitChain Constructor of the contract
//@:constructor
func (g *Governance) InitChain() {

}

const (
	//PubKeyLen is public key length
	PubKeyLen = 32
	//MaxNameLen is the max length of validator name
	MaxNameLen = 40
)

//InfoOfValidator validator struct
type InfoOfValidator struct {
	PubKey     []byte `json:"pub_key,omitempty"`     //节点公钥
	Power      int64  `json:"power,omitempty"`       //节点记账权重
	RewardAddr string `json:"reward_addr,omitempty"` //节点接收奖励的地址
	Name       string `json:"name,omitempty"`        //节点名称
	NodeAddr   string `json:"node_addr,omitempty"`   //节点地址
}

//RewardStrategy reward strategy
type RewardStrategy struct {
	Strategy     []Reward `json:"rewardStrategy,omitempty"` //奖励策略
	EffectHeight int64    `json:"effectHeight,omitempty"`   //生效高度
}

//Reward reward name percent and address
type Reward struct {
	Name          string `json:"name"`          // 被奖励者名称
	RewardPercent string `json:"rewardPercent"` // 奖励比例
	Address       string `json:"address"`       // 被奖励者地址
}

//NewValidator add a new validator
//@:public:method:gas[50000]
func (g *Governance) NewValidator(
	name string,
	pubKey types.PubKey,
	rewardAddr types.Address,
	power int64) {

	sdk.RequireOwner(g.sdk)
	sdk.Require(len(name) != 0 && len(name) <= MaxNameLen,
		types.ErrInvalidParameter, "Invalid name.")
	sdk.Require(len(pubKey) == PubKeyLen,
		types.ErrInvalidParameter, "Invalid pubKey.")
	sdk.RequireAddress(g.sdk, rewardAddr)
	sdk.Require(power > 0,
		types.ErrInvalidParameter, "Invalid power.")

	nodeAddr := g.sdk.Helper().BlockChainHelper().CalcAccountFromPubKey(pubKey)
	if g._chkValidator(nodeAddr) == true {
		sdk.Require(g._validator(nodeAddr).Power == 0,
			types.ErrInvalidParameter, "Validator is already exist.")
	}

	allValidators := g.getAllValidators()
	g.checkPower(nodeAddr, power, allValidators)
	for _, oldValidator := range allValidators {
		sdk.Require(oldValidator.Name != name,
			types.ErrInvalidParameter, "Validator's name is already exist.")
	}

	newValidator := InfoOfValidator{
		Name:       name,
		PubKey:     pubKey,
		NodeAddr:   nodeAddr,
		RewardAddr: rewardAddr,
		Power:      power,
	}
	g._setValidator(newValidator)

	allValidatorPubKeys := g._validatorPubKeys()
	allValidatorPubKeys = append(allValidatorPubKeys, pubKey)
	g._setValidatorPubKeys(allValidatorPubKeys)

	g.emitNewValidator(
		newValidator.Name,
		newValidator.PubKey,
		newValidator.NodeAddr,
		newValidator.RewardAddr,
		newValidator.Power,
	)
}

//SetPower set power for a validator
//@:public:method:gas[20000]
func (g *Governance) SetPower(pubKey types.PubKey, power int64) {

	sdk.RequireOwner(g.sdk)
	sdk.Require(len(pubKey) == PubKeyLen,
		types.ErrInvalidParameter, "Invalid pubKey.")
	sdk.Require(power >= 0,
		types.ErrInvalidParameter, "Invalid power.")

	nodeAddr := g.sdk.Helper().BlockChainHelper().CalcAccountFromPubKey(pubKey)
	validator := g._validator(nodeAddr)
	sdk.Require(g._chkValidator(nodeAddr) == true,
		types.ErrInvalidParameter, "Validator is not exist.")
	sdk.Require(validator.Power > 0,
		types.ErrInvalidParameter, "Validator is not exist.")

	allValidators := g.getAllValidators()
	g.checkPower(nodeAddr, power, allValidators)

	validator.Power = power
	g._setValidator(validator)

	g.emitSetPower(
		validator.Name,
		validator.PubKey,
		validator.NodeAddr,
		validator.RewardAddr,
		validator.Power,
	)
}

//SetRewardAddr set a reward address by pubKey
//@:public:method:gas[20000]
func (g *Governance) SetRewardAddr(pubKey types.PubKey, rewardAddr types.Address) {

	sdk.RequireOwner(g.sdk)
	sdk.Require(len(pubKey) == PubKeyLen,
		types.ErrInvalidParameter, "Invalid pubKey.")
	sdk.RequireAddress(g.sdk, rewardAddr)

	nodeAddr := g.sdk.Helper().BlockChainHelper().CalcAccountFromPubKey(pubKey)
	validator := g._validator(nodeAddr)
	sdk.Require(g._chkValidator(nodeAddr) == true,
		types.ErrInvalidParameter, "Validator is not exist.")
	sdk.Require(validator.Power > 0,
		types.ErrInvalidParameter, "Validator is not exist.")

	validator.RewardAddr = rewardAddr
	g._setValidator(validator)

	g.emitSetRewardAddr(
		validator.Name,
		validator.PubKey,
		validator.NodeAddr,
		validator.RewardAddr,
		validator.Power,
	)
}

//SetRewardStrategy update reward strategy
//@:public:method:gas[50000]
func (g *Governance) SetRewardStrategy(strategy string) {

	sdk.RequireOwner(g.sdk)

	rwdStrategy := g.checkRewardStrategy(strategy)
	g.updateRewardStrategy(rwdStrategy)
}

func (g *Governance) checkPower(nodeAddr types.Address, power int64, allValidators []InfoOfValidator) {

	totalPower := bn.N(power)
	maxPower := bn.N(power)

	for _, validator := range allValidators {
		if validator.NodeAddr != nodeAddr {
			totalPower = totalPower.AddI(validator.Power)
			if bn.N(validator.Power).IsGreaterThan(maxPower) {
				maxPower = bn.N(validator.Power)
			}
		}
	}

	// If the maxPower is equal to or over 1/3 totalPower, panic
	sdk.Require(maxPower.IsLessThan(totalPower.DivI(3)),
		types.ErrInvalidParameter, "Invalid power, max power is greater than or equal to 1/3 total power.")
}

func (g *Governance) checkRewardStrategy(strategy string) (rwdStrategy *RewardStrategy) {

	rwdStrategy = &RewardStrategy{}
	err := jsoniter.Unmarshal([]byte(strategy), rwdStrategy)
	sdk.RequireNotError(err, types.ErrInvalidParameter)

	g.checkRewardStrategyList(rwdStrategy.Strategy)
	g.checkEffectHeight(rwdStrategy.EffectHeight)

	return
}

func (g *Governance) checkRewardStrategyList(rwdStrategyList []Reward) {

	var percent float64
	var haveNameOfValidators bool

	for _, st := range rwdStrategyList {
		// check name length
		sdk.Require(len(st.Name) > 0 && len(st.Name) <= MaxNameLen,
			types.ErrInvalidParameter, "Invalid name in strategy")

		// check percent format
		if strings.Contains(st.RewardPercent, ".") {
			index := strings.IndexByte(st.RewardPercent, '.')
			sub := []byte(st.RewardPercent)[index+1:]
			sdk.Require(len(sub) == 2,
				types.ErrInvalidParameter, "Invalid reward percent")
		}

		nodePer, err := strconv.ParseFloat(st.RewardPercent, 64)
		sdk.RequireNotError(err, types.ErrInvalidParameter)

		percent = percent + nodePer
		sdk.Require(nodePer > 0.00 && percent <= 100.00,
			types.ErrInvalidParameter, "Invalid reward percent")

		// Check Address, check name with "validators", for validators, we don't care about its address
		if st.Name == "validators" {
			haveNameOfValidators = true
		} else {
			sdk.RequireAddress(g.sdk, st.Address)
		}
	}

	sdk.Require(percent == 100.00,
		types.ErrInvalidParameter, "Invalid reward percent")
	sdk.Require(haveNameOfValidators,
		types.ErrInvalidParameter, "Lose name of validators")
}

func (g *Governance) checkEffectHeight(effectHeight int64) {

	sdk.Require(effectHeight > g.sdk.Block().Height(),
		types.ErrInvalidParameter, "Invalid effect height: it should greater than current block height.")

	rewardStrategies := g._rewardStrategies()
	for _, item := range rewardStrategies {
		sdk.Require(effectHeight > item.EffectHeight,
			types.ErrInvalidParameter, "Invalid effect height: it should greater than others.")
	}
}

func (g *Governance) updateRewardStrategy(rwdStrategy *RewardStrategy) {

	rewardStrategies := g._rewardStrategies()
	rewardStrategies = append(rewardStrategies, *rwdStrategy)

	var first int
	for i, rewardStrategy := range rewardStrategies {
		if rewardStrategy.EffectHeight <= g.sdk.Block().Height() {
			first = i
		}
	}
	rewardStrategies = rewardStrategies[first:]
	g._setRewardStrategies(rewardStrategies)

	g.emitSetRewardStrategy(
		rwdStrategy.Strategy,
		rwdStrategy.EffectHeight,
	)
}

// get all validators
func (g *Governance) getAllValidators() (allValidators []InfoOfValidator) {

	sdk.Require(g._chkValidatorPubKeys(),
		types.ErrInvalidParameter, "Get all validators err, no pubKeys in db.")

	allPubKeys := g._validatorPubKeys()
	for _, pubKey := range allPubKeys {
		addr := g.sdk.Helper().BlockChainHelper().CalcAccountFromPubKey(pubKey)
		validator := g._validator(addr)
		if validator.Power > 0 {
			allValidators = append(allValidators, validator)
		}
	}
	return
}
