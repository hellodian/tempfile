package tokenissue

import (
	"blockchain/smcsdk/sdk"
	"blockchain/smcsdk/sdk/bn"
	"blockchain/smcsdk/sdk/std"
	"blockchain/smcsdk/sdk/types"
	"blockchain/smcsdk/sdkimpl/object"
)

//TokenIssue a genesis contract for issuing token and token management
//@:contract:token-issue
//@:version:2.0
//@:organization:orgJgaGConUyK81zibntUBjQ33PKctpk1K1G
//@:author:5e8339cb1a5cce65602fd4f57e115905348f7e83bcbe38dd77694dbe1f8903c9
type TokenIssue struct {
	sdk sdk.ISmartContract
}

const (
	// Define the minimum of token supply for issuing new token.
	// It's one TOKEN, 1,000,000,000 cong
	minTotalsupply = 1000000000
	// token name can be up to 40 characters
	maxNameLen = 40
	// token symbol can be up to 20 characters
	maxSymbolLen = 20
	// maximum gas price
	maxGasPrice = 1000000000
	// maximum number of accounts for batch transfer
	maxPerBatchTransfer = 1000
	// minimum name length for genesis organization issuing new token
	minNameLenForGenesisOrg = 2
	// minimum name length for other organization issuing new token
	minNameLenForOtherOrg = 3
	// minimum symbol length for genesis organization issuing new token
	minSymbolLenForGenesisOrg = 2
	// minimum symbol length for genesis organization issuing new token
	minSymbolLenForOtherOrg = 3
)

//InitChain Constructor of this TokenIssue
//@:constructor
func (ti *TokenIssue) InitChain() {

}

//NewToken register a token
//Notes: Once a token is registered by NewToken() call, it will own a contract exactly same with this contract,
//       but its contract cannot be used to register a new token again.
//       That means only the NewToken() of genesis contract of "token-issue" can be executed.
//       And the genesis contract "token-issue" will never own a token.
//@:public:method:gas[20000]
func (ti *TokenIssue) NewToken(
	name string,
	symbol string,
	totalSupply bn.Number,
	addSupplyEnabled bool,
	burnEnabled bool,
	gasprice int64) (addr types.Address) {

	// If it owns a token, it's not the genesis contract, cannot execute this function.
	sdk.Require(ti.sdk.Message().Contract().Token() == "",
		types.ErrNoAuthorization, "The contract has already registered a token")

	sdk.Require(ti.isValidNameAndSymbol(name, symbol),
		types.ErrInvalidParameter, "Invalid name or symbol")
	sdk.Require(totalSupply.IsEqualI(0) || totalSupply.IsGEI(minTotalsupply),
		types.ErrInvalidParameter, "Invalid total supply")
	sdk.Require(gasprice >= ti.sdk.Helper().TokenHelper().BaseGasPrice() && gasprice <= maxGasPrice,
		types.ErrInvalidParameter, "Invalid gas price")

	sender := ti.sdk.Message().Sender().Address()
	addr = ti.sdk.Helper().BlockChainHelper().CalcContractAddress(
		name,
		ti.sdk.Message().Contract().Version(),
		ti.sdk.Message().Contract().OrgID())
	token := std.Token{
		Address:          addr,
		Owner:            sender,
		Name:             name,
		Symbol:           symbol,
		TotalSupply:      totalSupply,
		AddSupplyEnabled: addSupplyEnabled,
		BurnEnabled:      burnEnabled,
		GasPrice:         gasprice,
	}
	sdb := ti.sdk.Helper().StateHelper()
	sdb.McSet(std.KeyOfToken(token.Address), &token)
	sdb.McSet(std.KeyOfTokenWithName(token.Name), &token.Address)
	sdb.McSet(std.KeyOfTokenWithSymbol(token.Symbol), &token.Address)

	allTokenAddr := new([]string)
	allTokenAddr = sdb.GetEx(std.KeyOfAllToken(), allTokenAddr).(*[]string)
	*allTokenAddr = append(*allTokenAddr, token.Address)
	sdb.McSet(std.KeyOfAllToken(), allTokenAddr)

	balance := std.AccountInfo{
		Address: token.Address,
		Balance: totalSupply,
	}
	sdb.McSet(std.KeyOfAccountToken(token.Owner, token.Address), &balance)
	acc := ti.sdk.Helper().AccountHelper().AccountOf(token.Owner)
	acc.(*object.Account).AddAccountTokenKey(std.KeyOfAccountToken(token.Owner, token.Address))

	contract := std.Contract{
		Address:      token.Address,
		Account:      ti.sdk.Helper().BlockChainHelper().CalcAccountFromName("token-template-"+name, ti.sdk.Message().Contract().OrgID()),
		Owner:        token.Owner,
		Name:         "token-template-" + name,
		Version:      ti.sdk.Message().Contract().Version(),
		CodeHash:     ti.sdk.Message().Contract().CodeHash(),
		EffectHeight: ti.sdk.Block().Height() + 1,
		Methods:      ti.sdk.Message().Contract().Methods(),
		Interfaces:   ti.sdk.Message().Contract().Interfaces(),
		Token:        token.Address,
		OrgID:        ti.sdk.Message().Contract().OrgID(),
	}
	sdb.McSet(std.KeyOfContract(contract.Address), &contract)

	sAddr := make([]types.Address, 0)
	sAddr = append(sAddr, contract.Address)
	sEff := make([]int64, 0)
	sEff = append(sEff, contract.EffectHeight)
	cvl := std.ContractVersionList{
		Name:             contract.Name,
		ContractAddrList: sAddr,
		EffectHeights:    sEff,
	}
	sdb.McSet(std.KeyOfContractsWithName(contract.OrgID, contract.Name), &cvl)

	cons := make([]types.Address, 0)
	key := std.KeyOfAccountContracts(contract.Owner)
	sdb.McGet(key, &cons)
	cons = append(cons, contract.Address)
	sdb.McSet(key, &cons)

	//Receipts -- token issue, transfer
	ti.sdk.Helper().ReceiptHelper().Emit(
		std.NewToken{
			TokenAddress:     token.Address,
			ContractAddress:  contract.Address,
			Owner:            token.Owner,
			Name:             token.Name,
			Symbol:           token.Symbol,
			TotalSupply:      token.TotalSupply,
			AddSupplyEnabled: token.AddSupplyEnabled,
			BurnEnabled:      token.BurnEnabled,
			GasPrice:         token.GasPrice,
		})

	ti.sdk.Helper().ReceiptHelper().Emit(
		std.Transfer{
			Token: token.Address,
			From:  "",
			To:    token.Owner,
			Value: totalSupply,
		})

	return
}

func (ti *TokenIssue) isValidLength(name, symbol string) bool {

	if ti.sdk.Helper().GenesisHelper().Token().Owner() == ti.sdk.Message().Sender().Address() {
		if len(name) < minNameLenForGenesisOrg || len(name) > maxNameLen {
			return false
		}
		if len(symbol) < minSymbolLenForGenesisOrg || len(symbol) > maxSymbolLen {
			return false
		}
	} else {
		if len(name) < minNameLenForOtherOrg || len(name) > maxNameLen {
			return false
		}
		if len(symbol) < minSymbolLenForOtherOrg || len(symbol) > maxSymbolLen {
			return false
		}
	}

	return true
}

func (ti *TokenIssue) isValidNameAndSymbol(name, symbol string) bool {

	if ti.isValidLength(name, symbol) == false {
		return false
	}

	t1 := ti.sdk.Helper().TokenHelper().TokenOfName(name)
	t2 := ti.sdk.Helper().TokenHelper().TokenOfSymbol(symbol)
	if t1 == nil && t2 == nil {
		//valid new token name and symbol
		return true
	} else if t1 != nil && t2 != nil && t1.Address() == t2.Address() &&
		t1.TotalSupply().IsEqualI(0) && t2.TotalSupply().IsEqualI(0) &&
		t1.Owner() == ti.sdk.Message().Sender().Address() {
		//Registered with total supply = 0, return true
		return true
	}
	return false
}

//Transfer transfers token to an account
//@:public:method:gas[600]
//@:public:interface:gas[540]
func (ti *TokenIssue) Transfer(to types.Address, value bn.Number) {

	// If it is the genesis contract, cannot execute this function.
	sdk.Require(ti.sdk.Message().Contract().Token() != "",
		types.ErrNoAuthorization, "The contract has not a token")

	ti.sdk.Message().Sender().Transfer(to, value)
}

//BatchTransfer transfers token to multi accounts
//@:public:method:gas[6000]
func (ti *TokenIssue) BatchTransfer(toList []types.Address, value bn.Number) {

	// If it is the genesis contract, cannot execute this function.
	sdk.Require(ti.sdk.Message().Contract().Token() != "",
		types.ErrNoAuthorization, "The contract has not a token")

	sdk.Require(len(toList) > 0,
		types.ErrInvalidParameter, "Address list cannot be empty")
	sdk.Require(len(toList) <= maxPerBatchTransfer,
		types.ErrInvalidParameter, "Number of accounts is out of range")

	for _, to := range toList {
		ti.sdk.Message().Sender().Transfer(to, value)
	}
}

//AddSupply add token's supply after it's issued
//@:public:method:gas[2400]
func (ti *TokenIssue) AddSupply(value bn.Number) {

	// If it is the genesis contract, cannot execute this function.
	sdk.Require(ti.sdk.Message().Contract().Token() != "",
		types.ErrNoAuthorization, "The contract has not a token")

	sdk.Require(value.IsGreaterThanI(0),
		types.ErrInvalidParameter, "Value cannot be negative")

	newTotalSupply := ti.sdk.Helper().TokenHelper().Token().TotalSupply().Add(value)
	ti.sdk.Helper().TokenHelper().Token().SetTotalSupply(newTotalSupply)
}

//Burn burn token's supply after it's issued
//@:public:method:gas[2400]
func (ti *TokenIssue) Burn(value bn.Number) {

	// If it is the genesis contract, cannot execute this function.
	sdk.Require(ti.sdk.Message().Contract().Token() != "",
		types.ErrNoAuthorization, "The contract has not a token")

	sdk.Require(value.IsGreaterThanI(0),
		types.ErrInvalidParameter, "Value cannot be negative")

	newTotalSupply := ti.sdk.Helper().TokenHelper().Token().TotalSupply().Sub(value)
	sdk.Require(newTotalSupply.IsGEI(0),
		types.ErrInvalidParameter, "New totalsupply cannot be negative")

	ti.sdk.Helper().TokenHelper().Token().SetTotalSupply(newTotalSupply)
}

//SetOwner set a new owner to token after it's issued
//@:public:method:gas[2400]
func (ti *TokenIssue) SetOwner(newOnwer types.Address) {
	ti.sdk.Message().Contract().SetOwner(newOnwer)
}

//SetGasPrice set token's gasprice after it's issued
//@:public:method:gas[2400]
func (ti *TokenIssue) SetGasPrice(value int64) {

	// If it is the genesis contract, cannot execute this function.
	sdk.Require(ti.sdk.Message().Contract().Token() != "",
		types.ErrNoAuthorization, "The contract has not a token")

	ti.sdk.Helper().TokenHelper().Token().SetGasPrice(value)
}
